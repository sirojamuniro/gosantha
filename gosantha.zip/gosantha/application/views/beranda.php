<!DOCTYPE html>
<html>

<head>

    <link href="<?php echo base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/bootstrap.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/bootstrap-theme.css') ?>" rel="stylesheet">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>

<body>

    <script src="<?php echo base_url('assets/bootstrap/js/jquery.min.js') ?>"></script>

    <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
    <nav class="nav">
        <a class="nav-link active" href="<?php echo base_url().'index.php/repo'?>">Beranda</a>

        <a class="nav-link active" href="<?php echo base_url().'index.php/repo/tabel'?>">Tabel</a>
    </nav>
    <div class="jumbotron text-center">
        <center>
            <h1>Halaman Utama</h1>
        </center>
    </div>
    <div class="table table-bordered">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Pemegang</th>
                    <th scope="col">Nama Toko</th>

                </tr>
            </thead>
            <tbody>
                <?php
               
$no = 1;

$supp = array("Supplier","Supplier","Pelanggan","Pelanggan","Supplier");

foreach($relasi as $u){
?>
                <tr>
                    <td><?php echo $no++ ?></td>
                    <td>Supplier</td>
                    <td><?php echo $u->nama ?></td>

                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>

</html>