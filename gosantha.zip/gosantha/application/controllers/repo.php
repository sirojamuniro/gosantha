<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Repo extends CI_Controller{

    
function index(){
    $this->load->model('relasi');
    $this->load->helper('url');
    $data['relasi'] = $this->relasi->GetListRelasi()->result();
    $supp = array("Supplier","Supplier","Pelanggan","Pelanggan","Supplier");
    
    $this->load->view('beranda',$data);
}
function tabel(){
    $this->load->model('relasi');
    $this->load->helper('url');
    $data['relasi'] = $this->relasi->GetListRelasi()->result();
    $this->load->view('v_tampil',$data);
}
}