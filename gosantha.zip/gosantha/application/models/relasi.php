<?php
class Relasi extends CI_Model{
function GetListRelasi()
{
return $this->db->get('relasi');
}          


function rubah ($tipe){
    $ansi= $this->db->get_where('relasi', array('id' => $id, 'tipe' => 'Vendor'))->num_rows();
    
}
}